import React from 'react';
import Gallery from './Gallery';
//import { FormatAlignCenter } from '@material-ui/icons';
function App() {
  return (
    <>
    <h1 style={{textAlign:'center'}}>Tutorial 5</h1>
    <Gallery/>
    </>
  );
}

export default App;
