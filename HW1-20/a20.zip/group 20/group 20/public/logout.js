 

// Function for "Login without account" button (just an example)
function logout() {
    alert("logout.");
    // Implement action as needed
    window.location.href = "./home.html";
}